import os
import sys
import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog, ttk
from PIL import Image, ImageTk, ImageDraw, ImageFont
import threading
import time
import subprocess
import webbrowser
import pickle
import mediapipe as mp

class Config:
    DARK_GRAY = "#1a1a1a"
    DARKER_GRAY = "#121212"
    MEDIUM_GRAY = "#2d2d2d"
    LIGHT_GRAY = "#3c3c3c"
    GRID_BG = "#252525"
    GRID_TILE = "#363636"
    GRID_BORDER = "#404040"
    ACCENT_BLUE = "#3498db"
    ACCENT_GREEN = "#2ecc71"
    ACCENT_RED = "#e74c3c"
    ACCENT_PURPLE = "#9b59b6"
    TEXT_WHITE = "#ffffff"
    TEXT_LIGHT = "#ecf0f1"
    
    MAIN_WIDTH = 1400
    MAIN_HEIGHT = 900
    EMOTION_WIDTH = 500
    EMOTION_HEIGHT = 600
    RED_ZONE_HEIGHT = 100

class SettingsManager:
    def __init__(self):
        self.settings = {
            'finger_actions': {},
            'finger_colors': self._get_finger_colors()
        }
        if getattr(sys, 'frozen', False):
           self.base_path = os.path.dirname(sys.executable)
        else:
           self.base_path = os.path.dirname(os.path.abspath(__file__))
    
    def _get_finger_colors(self):
        return {
            'finger1': "#FF1D1D", 'finger2': '#4ECDC4',
            'finger3': '#45B7D1', 'finger4': '#96CEB4',
            'finger5': '#FFEAA7', 'finger6': '#DDA0DD',
            'finger7': '#87CEEB', 'finger8': '#98FB98',
            'finger9': '#FFB6C1', 'finger10': '#FFD700'
        }
    
    def save(self):
        try:
            with open('settings.pkl', 'wb') as f:
                pickle.dump(self.settings, f)
        except Exception as e:
            print(f"Ошибка сохранения: {e}")
    
    def load(self):
        try:
            if os.path.exists('settings.pkl'):
                with open('settings.pkl', 'rb') as f:
                    self.settings = pickle.load(f)
        except:
            print("Не удалось загрузить настройки")
    
    def set_finger_action(self, finger_name, action_type, path, browser=""):
        self.settings['finger_actions'][finger_name] = {
            'type': action_type,
            'path': path,
            'browser': browser
        }
        self.save()
    
    def get_finger_action(self, finger_name):
        return self.settings['finger_actions'].get(finger_name)
    
class HandFaceTracker:
    def __init__(self, settings):
        self.mp_hands = mp.solutions.hands
        self.mp_face_detection = mp.solutions.face_detection
        self.mp_drawing = mp.solutions.drawing_utils
        
        self.hands = self.mp_hands.Hands(
            max_num_hands=2,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.5,
            static_image_mode=False
        )
        
        self.face_detector = self.mp_face_detection.FaceDetection(
            min_detection_confidence=0.5
        )

        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_mesh = self.mp_face_mesh.FaceMesh(
            max_num_faces=1,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
 
        self.finger_colors = []
        for hex_color in settings.settings['finger_colors'].values():
            r = int(hex_color[1:3], 16)
            g = int(hex_color[3:5], 16)
            b = int(hex_color[5:7], 16)
            self.finger_colors.append((r, g, b))
        
        self.hand_connections_style = self.mp_drawing.DrawingSpec(
            color=(0, 255, 0), thickness=2
        )
        self.joint_style = self.mp_drawing.DrawingSpec(
            color=(255, 255, 255), thickness=2, circle_radius=4
        )
    
    def detect_emotion_from_landmarks(self, face_landmarks, img_shape):
        if face_landmarks is None:
            return "neutral"

        left_mouth = face_landmarks.landmark[61]
        right_mouth = face_landmarks.landmark[291]
        upper_lip = face_landmarks.landmark[13]
        lower_lip = face_landmarks.landmark[14]
        left_eyebrow = face_landmarks.landmark[70]
        
        mouth_width = abs(left_mouth.x - right_mouth.x)
        mouth_open = abs(upper_lip.y - lower_lip.y)
        
        if mouth_open > 0.02:
            return "happy"
        elif left_eyebrow.y > 0.3:
            return "angry"
        elif mouth_width < 0.15 and left_eyebrow.y > 0.35:
            return "sad"
        else:
            return "neutral"
    
    def detect_hands_and_face(self, frame):
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        hands_results = self.hands.process(rgb_frame)
        face_results = self.face_detector.process(rgb_frame)
        face_mesh_results = self.face_mesh.process(rgb_frame)
        return hands_results, face_results, face_mesh_results
    
    def draw_detections(self, frame, hands_results, face_results, emotion_text="neutral"):
        h, w, _ = frame.shape

        if hands_results.multi_hand_landmarks:
           for hand_idx, hand_landmarks in enumerate(hands_results.multi_hand_landmarks):
               self.mp_drawing.draw_landmarks(
                   frame,
                   hand_landmarks,
                   self.mp_hands.HAND_CONNECTIONS,
                   self.hand_connections_style,
                   self.joint_style
                )

               base_idx = 0
               if hands_results.multi_handedness:
                  handedness = hands_results.multi_handedness[hand_idx].classification[0].label
                  base_idx = 0 if handedness == "Left" else 5
               else:
                  base_idx = hand_idx * 5

               finger_tip_indices = [4, 8, 12, 16, 20]
               for i, tip_idx in enumerate(finger_tip_indices):
                   landmark = hand_landmarks.landmark[tip_idx]
                   cx, cy = int(landmark.x * w), int(landmark.y * h)
                   color_idx = (base_idx + i) % len(self.finger_colors)
                   color = self.finger_colors[color_idx]
                   cv2.circle(frame, (cx, cy), 12, color, -1)
                   cv2.circle(frame, (cx, cy), 14, (255, 255, 255), 2)
                   finger_number = base_idx + i + 1
                   cv2.putText(frame, str(finger_number), (cx-5, cy-15),
                              cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        if face_results.detections:
            for detection in face_results.detections:
                bbox = detection.location_data.relative_bounding_box
                x = int(bbox.xmin * w)
                y = int(bbox.ymin * h)
                width = int(bbox.width * w)
                height = int(bbox.height * h)
                
                overlay = frame.copy()
                cv2.rectangle(overlay, (x, y), (x+width, y+height), (0, 255, 0), 2)
                cv2.addWeighted(overlay, 0.2, frame, 0.8, 0, frame)
                cv2.putText(frame, emotion_text.upper(), (x, y-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
        
        return frame
    
    def get_finger_tips(self, hands_results, w, h):
       finger_tips = []
       if hands_results.multi_hand_landmarks and hands_results.multi_handedness:
         for hand_idx, hand_landmarks in enumerate(hands_results.multi_hand_landmarks):
            handedness = hands_results.multi_handedness[hand_idx].classification[0].label
            base_idx = 0 if handedness == "Left" else 5
            finger_tip_indices = [4, 8, 12, 16, 20]
            for i, tip_idx in enumerate(finger_tip_indices):
                lm = hand_landmarks.landmark[tip_idx]
                cx, cy = int(lm.x * w), int(lm.y * h)
                color_idx = (base_idx + i) % len(self.finger_colors)
                color = self.finger_colors[color_idx]
                finger_tips.append({
                    'x': cx, 'y': cy,
                    'color': color,
                    'finger_name': f'finger{base_idx + i + 1}'
                })
       return finger_tips

class ModernTile(tk.Frame):
    def __init__(self, parent, title="", width=200, height=200, **kwargs):
        super().__init__(parent, width=width, height=height,
                        bg=Config.GRID_TILE,
                        highlightbackground=Config.GRID_BORDER,
                        highlightthickness=2, **kwargs)
        if title:
            tk.Label(self, text=title.upper(), font=("Segoe UI", 10, "bold"),
                    bg=Config.GRID_TILE, fg=Config.TEXT_WHITE).pack(pady=5)
        self.content = tk.Frame(self, bg=Config.GRID_TILE)
        self.content.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

class AICameraStudio:
    def __init__(self):
        self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            self.cap = cv2.VideoCapture(1, cv2.CAP_DSHOW)
        if not self.cap.isOpened():
            print("❌ Камера не найдена")
            self.root = tk.Tk()
            self.root.title("Ошибка")
            tk.Label(self.root, text="Камера не найдена", fg="red", font=("Arial", 20)).pack(padx=50, pady=50)
            self.root.mainloop()
            return
        
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
        
        self.settings = SettingsManager()
        self.settings.load()
        self.tracker = HandFaceTracker(self.settings)
        
        self.running = True
        self.current_emotion = "neutral"
        self.fps = 0
        self.frame_count = 0
        self.last_time = time.time()
        
        self.emotion_window = None
        self.control_window = None
        self.hah_window = None
        self.hah_image = None
        
        self.emotion_images = self.load_emotion_images()
        self.prev_fingers_in_zone = set()
        
        self.create_main_window()
        self.create_emotion_window()
        
        self.camera_thread = threading.Thread(target=self.camera_loop, daemon=True)
        self.camera_thread.start()
    
    def get_base_path(self):
        if getattr(sys, 'frozen', False):
           return os.path.dirname(sys.executable)
        else:
           return os.path.dirname(os.path.abspath(__file__))
    
    def load_emotion_images(self):
        emotions = {}
        emotion_files = {
           'angry': 'agli.png',
           'happy': 'happe.png',
           'neutral': 'natur.png',
           'sad': 'tired.png'
        }
        base = self.get_base_path()
        for emotion, filename in emotion_files.items():
            path = os.path.join(base, 'emotions', filename)
            if os.path.exists(path):
                try:
                   img = Image.open(path).resize((180, 180), Image.Resampling.LANCZOS)
                   emotions[emotion] = img
                except:
                   emotions[emotion] = self.create_default_image(emotion)
            else:
                emotions[emotion] = self.create_default_image(emotion)
        return emotions
    
    def create_default_image(self, emotion):
        img = Image.new('RGB', (180, 180), Config.GRID_TILE)
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype("arial.ttf", 20)
        except:
            font = ImageFont.load_default()
        draw.text((50, 80), emotion.upper(), fill=Config.TEXT_WHITE, font=font)
        return img
    
    def create_main_window(self):
        self.root = tk.Tk()
        self.root.title("AI Camera Studio")
        self.root.geometry(f"{Config.MAIN_WIDTH}x{Config.MAIN_HEIGHT}")
        self.root.configure(bg=Config.DARK_GRAY)
        self.root.config(highlightbackground=Config.DARKER_GRAY, highlightthickness=2)
        
        main_frame = tk.Frame(self.root, bg=Config.DARK_GRAY)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        top_panel = tk.Frame(main_frame, bg=Config.DARK_GRAY)
        top_panel.pack(fill=tk.X, pady=(0,10))
        
        title_frame = tk.Frame(top_panel, bg=Config.DARK_GRAY)
        title_frame.pack(side=tk.LEFT)
        tk.Label(title_frame, text="👁", font=("Arial", 24),
                bg=Config.DARK_GRAY, fg=Config.ACCENT_BLUE).pack(side=tk.LEFT, padx=5)
        tk.Label(title_frame, text="AI CAMERA STUDIO", font=("Arial", 24, "bold"),
                bg=Config.DARK_GRAY, fg=Config.TEXT_WHITE).pack(side=tk.LEFT)
        
        self.fps_label = tk.Label(top_panel, text="FPS: 00", font=("Arial", 12, "bold"),
                                 bg=Config.ACCENT_BLUE, fg=Config.TEXT_WHITE, padx=10, pady=5)
        self.fps_label.pack(side=tk.RIGHT, padx=10)
        
        video_container = tk.Frame(main_frame, bg=Config.DARKER_GRAY)
        video_container.pack(fill=tk.BOTH, expand=True)
        
        # Красная зона
        self.red_zone_frame = tk.Frame(video_container, height=Config.RED_ZONE_HEIGHT, bg=Config.DARK_GRAY)
        self.red_zone_frame.pack(fill=tk.X, pady=(0,5))
        self.red_zone_canvas = tk.Canvas(self.red_zone_frame, height=Config.RED_ZONE_HEIGHT,
                                         bg=Config.DARK_GRAY, highlightthickness=0)
        self.red_zone_canvas.pack(fill=tk.X)
        self.red_zone_canvas.bind("<Configure>", self.update_red_zone)
        
        self.video_frame = tk.Frame(video_container, bg=Config.MEDIUM_GRAY)
        self.video_frame.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        self.video_label = tk.Label(self.video_frame, bg=Config.MEDIUM_GRAY)
        self.video_label.pack(fill=tk.BOTH, expand=True)

        self.control_frame = tk.Frame(video_container, bg=Config.DARK_GRAY)
        self.control_frame.place(relx=0.98, rely=0.98, anchor='se')
        self.control_canvas = tk.Canvas(self.control_frame, width=50, height=50,
                                        bg=Config.DARK_GRAY, highlightthickness=0)
        self.control_canvas.pack()
        self.control_canvas.create_oval(5,5,45,45, fill=Config.ACCENT_BLUE,
                                        outline=Config.GRID_BORDER, width=2)
        self.control_canvas.create_text(25,25, text="⚙", font=("Arial", 20),
                                        fill=Config.TEXT_WHITE)
        self.control_canvas.bind("<Button-1>", lambda e: self.open_control_window())
        self.control_canvas.bind("<Enter>", lambda e: self.control_canvas.itemconfig(1, fill=Config.ACCENT_GREEN))
        self.control_canvas.bind("<Leave>", lambda e: self.control_canvas.itemconfig(1, fill=Config.ACCENT_BLUE))
    
    def update_red_zone(self, event):
        w = event.width
        self.red_zone_canvas.delete("all")
        self.red_zone_canvas.create_rectangle(0, 0, w, Config.RED_ZONE_HEIGHT,
                                              fill='', outline=Config.ACCENT_RED,
                                              width=3, dash=(5,5))
        self.red_zone_canvas.create_text(100, Config.RED_ZONE_HEIGHT//2,
                                         text="RED ZONE", font=("Arial", 12, "bold"),
                                         fill=Config.ACCENT_RED, anchor='w')
    
    def create_emotion_window(self):
        self.emotion_window = tk.Toplevel(self.root)
        self.emotion_window.title("Emotions")
        self.emotion_window.geometry(f"{Config.EMOTION_WIDTH}x{Config.EMOTION_HEIGHT}")
        self.emotion_window.configure(bg=Config.DARK_GRAY)
        self.emotion_window.config(highlightbackground=Config.DARKER_GRAY, highlightthickness=2)
        
        header = tk.Frame(self.emotion_window, bg=Config.ACCENT_BLUE, height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="EMOTIONS", font=("Arial", 16, "bold"),
                bg=Config.ACCENT_BLUE, fg=Config.TEXT_WHITE).pack(pady=15)
        
        grid_frame = tk.Frame(self.emotion_window, bg=Config.GRID_BG)
        grid_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        self.emotion_tiles = {}
        emotions = list(self.emotion_images.keys())
        for i, emotion in enumerate(emotions):
            row, col = i//2, i%2
            tile = ModernTile(grid_frame, title=emotion, width=200, height=200)
            tile.grid(row=row, column=col, padx=10, pady=10, sticky="nsew")
            grid_frame.grid_rowconfigure(row, weight=1)
            grid_frame.grid_columnconfigure(col, weight=1)
            
            photo = ImageTk.PhotoImage(self.emotion_images[emotion])
            lbl = tk.Label(tile.content, image=photo, bg=Config.GRID_TILE)
            lbl.image = photo
            lbl.pack(expand=True)
            self.emotion_tiles[emotion] = tile
    
    def open_control_window(self):
        if self.control_window and self.control_window.winfo_exists():
            self.control_window.lift()
            return
        self.control_window = tk.Toplevel(self.root)
        self.control_window.title("Finger Actions")
        self.control_window.geometry("600x500")
        self.control_window.configure(bg=Config.DARK_GRAY)
        self.control_window.config(highlightbackground=Config.DARKER_GRAY, highlightthickness=2)
        
        header = tk.Frame(self.control_window, bg=Config.ACCENT_BLUE, height=50)
        header.pack(fill=tk.X)
        tk.Label(header, text="FINGER ACTIONS", font=("Arial", 12, "bold"),
                bg=Config.ACCENT_BLUE, fg=Config.TEXT_WHITE).pack(pady=15)

        canvas = tk.Canvas(self.control_window, bg=Config.DARK_GRAY, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.control_window, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=Config.DARK_GRAY)
        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True, padx=20, pady=20)
        scrollbar.pack(side="right", fill="y")
        
        colors = list(self.settings.settings['finger_colors'].values())
        for i in range(10):
            finger_name = f'finger{i+1}'
            saved_action = self.settings.get_finger_action(finger_name)
            saved_path = saved_action['path'] if saved_action else ''
            saved_browser = saved_action['browser'] if saved_action else 'default'
            color = colors[i%10]
            
            tile = ModernTile(scroll_frame, title=f"FINGER {i+1}", width=550, height=80)
            tile.pack(fill=tk.X, pady=5)

            color_disp = tk.Canvas(tile.content, width=30, height=30, bg=color, highlightthickness=0)
            color_disp.pack(side=tk.LEFT, padx=(0,10))
            
            path_var = tk.StringVar(value=saved_path)
            entry = tk.Entry(tile.content, textvariable=path_var, width=35,
                             bg=Config.LIGHT_GRAY, fg=Config.TEXT_WHITE,
                             insertbackground=Config.TEXT_WHITE)
            entry.pack(side=tk.LEFT, padx=5)
            self.add_right_click_menu(entry)
            
            browse_btn = tk.Button(tile.content, text="📁",
                                   command=lambda v=path_var: self.browse_file(v),
                                   bg=Config.ACCENT_BLUE, fg=Config.TEXT_WHITE,
                                   relief=tk.FLAT)
            browse_btn.pack(side=tk.LEFT, padx=2)
            
            browser_var = tk.StringVar(value=saved_browser)
            browser_combo = ttk.Combobox(tile.content, textvariable=browser_var,
                                         values=["default","chrome","firefox","edge"],
                                         width=12, state="readonly")
            browser_combo.pack(side=tk.LEFT, padx=5)
            
            save_btn = tk.Button(tile.content, text="💾",
                                 command=lambda fn=finger_name, pv=path_var, bv=browser_var:
                                     self.save_action(fn, pv.get(), bv.get()),
                                 bg=Config.ACCENT_GREEN, fg=Config.TEXT_WHITE,
                                 relief=tk.FLAT)
            save_btn.pack(side=tk.RIGHT, padx=10)
    
    def add_right_click_menu(self, entry):
        menu = tk.Menu(entry, tearoff=0)
        menu.add_command(label="Вставить", command=lambda: entry.event_generate("<<Paste>>"))
        def show_menu(event):
            menu.tk_popup(event.x_root, event.y_root)
        entry.bind("<Button-3>", show_menu)
    
    def browse_file(self, path_var):
        f = filedialog.askopenfilename(filetypes=[("Все файлы","*.*"), ("Приложения","*.exe;*.lnk")])
        if f:
            path_var.set(f)
    
    def save_action(self, finger_name, path, browser):
        if path:
            typ = 'url' if path.startswith('http') else 'app'
            self.settings.set_finger_action(finger_name, typ, path, browser)
            print(f"✅ Сохранено для {finger_name}")
    
    def check_red_zone(self, finger_tips):
        red_zone_y = Config.RED_ZONE_HEIGHT
        current_fingers = set()
        for tip in finger_tips:
            if tip['y'] < red_zone_y:
                current_fingers.add(tip['finger_name'])
        
        new_fingers = current_fingers - self.prev_fingers_in_zone
        for finger_name in new_fingers:
            if finger_name == 'finger10':
                self.show_hah_image()
            else:
                action = self.settings.get_finger_action(finger_name)
                if action:
                    self.execute_action(action)
        
        if 'finger10' not in current_fingers:
            self.hide_hah_image()
        
        self.prev_fingers_in_zone = current_fingers
        return bool(current_fingers)
    
    def execute_action(self, action):
        try:
            if action['type'] == 'app':
               subprocess.Popen([action['path']], shell=False)
            else:
               webbrowser.open(action['path'])
            print(f"🚀 Выполнено действие: {action['path']}")
        except Exception as e:
            print(f"❌ Ошибка выполнения: {e}")
    
    def show_hah_image(self):
        if self.hah_window and self.hah_window.winfo_exists():
           return
        base = self.get_base_path()
        hah_path = os.path.join(base, 'emotions', 'hah.png')
        if os.path.exists(hah_path):
            self.hah_window = tk.Toplevel(self.root)
            self.hah_window.attributes('-fullscreen', True)
            img = Image.open(hah_path)
            sw, sh = self.hah_window.winfo_screenwidth(), self.hah_window.winfo_screenheight()
            img = img.resize((sw, sh), Image.Resampling.LANCZOS)
            self.hah_image = ImageTk.PhotoImage(img)
            tk.Label(self.hah_window, image=self.hah_image, bg='black').pack(fill=tk.BOTH, expand=True)
            tk.Button(self.hah_window, text="✕", command=self.hide_hah_image,
                     font=("Arial",20), bg=Config.ACCENT_RED, fg=Config.TEXT_WHITE,
                     relief=tk.FLAT).place(relx=1.0, x=-20, y=20, anchor='ne')
    
    def hide_hah_image(self):
        if self.hah_window:
            self.hah_window.destroy()
            self.hah_window = None
    
    def update_emotion_display(self):
        if not self.emotion_window:
            return
        for emotion, tile in self.emotion_tiles.items():
            if emotion == self.current_emotion:
                tile.config(highlightbackground=Config.ACCENT_BLUE, highlightthickness=3)
            else:
                tile.config(highlightbackground=Config.GRID_BORDER, highlightthickness=2)
    
    def camera_loop(self):
        while self.running:
            ret, frame = self.cap.read()
            if not ret:
                continue
            frame = cv2.flip(frame, 1)
            
            try:
                hands_results, face_results, face_mesh_results = self.tracker.detect_hands_and_face(frame)

                if face_mesh_results.multi_face_landmarks:
                    face_landmarks = face_mesh_results.multi_face_landmarks[0]
                    emotion_text = self.tracker.detect_emotion_from_landmarks(face_landmarks, frame.shape)
                    self.current_emotion = emotion_text
                else:
                    self.current_emotion = "neutral"
                
                frame = self.tracker.draw_detections(frame, hands_results, face_results, self.current_emotion)
                
                h, w, _ = frame.shape
                finger_tips = self.tracker.get_finger_tips(hands_results, w, h)
                self.check_red_zone(finger_tips)
            except Exception as e:
                print(f"Ошибка обработки кадра: {e}")
            
            self.frame_count += 1
            if time.time() - self.last_time >= 1.0:
                self.fps = self.frame_count
                self.frame_count = 0
                self.last_time = time.time()
                self.root.after(0, lambda: self.fps_label.config(text=f"FPS: {self.fps:02d}"))
                self.root.after(0, self.update_emotion_display)
            
            vw, vh = self.video_label.winfo_width(), self.video_label.winfo_height()
            if vw > 10 and vh > 10:
                h, w = frame.shape[:2]
                scale = min(vw/w, vh/h)
                nw, nh = int(w*scale), int(h*scale)
                frame = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
            
            img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(img_rgb)
            photo = ImageTk.PhotoImage(img)
            self.root.after(0, lambda p=photo: self.update_video(p))
            
            time.sleep(0.03)
    
    def update_video(self, photo):
        try:
            self.video_label.config(image=photo)
            self.video_label.image = photo
        except:
            pass
    
    def run(self):
        if hasattr(self, 'root'):
            self.root.mainloop()
    
    def cleanup(self):
        self.running = False
        if self.cap:
            self.cap.release()
        cv2.destroyAllWindows()
        self.settings.save()

if __name__ == "__main__":
    print("="*60)
    print("AI CAMERA STUDIO v6.0 - ПОЛНОСТЬЮ РАБОЧАЯ ВЕРСИЯ")
    print("="*60)
    app = AICameraStudio()
    if hasattr(app, 'root'):
        app.run()
        app.cleanup()
    else:
        input("Нажмите Enter для выхода...")